import random
from figur import Figur

class Ball(Figur):
    def __init__(self, x: int, y: int):
        super().__init__(x, y, "yellow")

